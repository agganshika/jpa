insert into alien values(105, 'Navin','Java');
insert into alien values(106, 'Pritiksha','Sql');
insert into alien values(107, 'Deepika','Python');
insert into alien values(108, 'Neha','Android');
insert into alien values(109, 'Komal','Scala');
insert into alien values(110, 'Naina','Java');