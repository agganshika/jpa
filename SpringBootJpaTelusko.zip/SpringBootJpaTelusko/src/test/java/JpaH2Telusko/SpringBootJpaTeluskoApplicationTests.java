package JpaH2Telusko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaTeluskoApplicationTests {

	@Test
	void contextLoads() {
	}

}
